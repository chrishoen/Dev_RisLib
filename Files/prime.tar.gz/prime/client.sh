#!/bin/sh

/opt/prime/bin/ProtoTcpClientMsg -client1
