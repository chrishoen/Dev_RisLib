#!/bin/sh


/usr/bin/screen  -dmS comm -c /opt/prime/screen_cproc
