#!/bin/sh

/opt/prime/bin/ProtoUdpMsg -peer1
