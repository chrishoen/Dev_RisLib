#!/bin/sh

#sudo /opt/prime/bin/ProtoUdpString -peer1
#sudo /opt/prime/bin/ProtoUdpMsg -peer1
sudo /opt/prime/bin/ProtoTcpServerMsg
