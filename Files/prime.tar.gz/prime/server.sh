#!/bin/sh

/opt/prime/bin/ProtoTcpServerMsg
