#!/bin/sh


screen -S comm -X quit

exit


