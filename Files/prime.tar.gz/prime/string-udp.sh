#!/bin/sh

#sudo /opt/prime/bin/ProtoUdpMsg -peer1
/opt/prime/bin/ProtoUdpString -peer1
