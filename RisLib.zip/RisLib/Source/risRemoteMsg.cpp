/*==============================================================================
==============================================================================*/

//******************************************************************************
//******************************************************************************
//******************************************************************************

#include <stdio.h>
#include <string.h>
#include "risRemoteMsg.h"


namespace Ris
{
namespace RemoteMsg
{

//******************************************************************************
//******************************************************************************
//******************************************************************************

Header::Header()
{
   mSyncWord1      = 0xaaaaaaaa;
   mSyncWord2      = 0xbbbbbbbb;
   mMessageType    = 0;
   mMessageLength  = 0;
   mFamily         = 0;
   mSourceId       = 0;
   mDestinationId  = 0;
}

void Header::copyToFrom(Ris::ByteBuffer* aBuffer)
{
   aBuffer->copy(& mSyncWord1     );
   aBuffer->copy(& mSyncWord2     );
   aBuffer->copy(& mMessageType   );
   aBuffer->copy(& mMessageLength );
   aBuffer->copy(& mFamily        );
   aBuffer->copy(& mSourceId      );
   aBuffer->copy(& mDestinationId );
}

bool Header::validateBuffer(Ris::ByteBuffer* aBuffer)
{
   bool error =
      aBuffer->getError() ||
      aBuffer->getLength() < Length ||
      aBuffer->getLength() > MsgBufferSize;

   return !error;
}

bool Header::validateContent()
{
   bool error =
      mSyncWord1 != 0xaaaaaaaa ||
      mSyncWord2 != 0xbbbbbbbb ||
      mMessageLength < Length  ||
      mMessageLength > MsgBufferSize;

   return !error;
}

//------------------------------------------------------------------------------
// These are called explicitly by inheriting messages at the
// beginning and end of their copyToFrom's to manage the headers.
// For "get" operations, headerCopyToFrom "gets" the header and
// headerReCopyToFrom does nothing. For "put" operations,
// headerCopyToFrom does nothing except store the buffer pointer and
// headerReCopyToFrom "puts" the header at the stored position. Both
// functions are passed a byte buffer pointer to where the copy is
// to take place. Both are also passed a MessageContent pointer to
// where they can get MessageContent::mFamily and mMessageType which
// they transfer into and out of the headers.
//------------------------------------------------------------------------------

void Header::headerCopyToFrom (Ris::ByteBuffer* aBuffer,Ris::MessageContent* parent)
{

   //---------------------------------------------------------------------
   // Instances of this class are members of parent message classes.
   // A call to this function should be the first line of code in a
   // containing parent message class's copyToFrom. It performs pre-copyToFrom
   // operations. It's purpose is to copy headers to/from byte buffers. The
   // corresponding function headerReCopyToFrom should be called as the last
   // line of code in the containing message class' copyToFrom. Lines of code
   // in between should copy individual data elements into/out of the buffer.

   //---------------------------------------------------------------------
   // for a "copy to" put
   //
   // If this is a "copy to" put operation then the header copy will actually
   // be done by the headerReCopyToFrom, after the rest of the message has been
   // copied into the buffer. This is because some of the fields in the header
   // cannot be set until after the rest of the message has been put into the
   // buffer. (You don't know the length of the message until you put all of
   // the data into it, you also can't compute a checksum). This call stores
   // the original buffer position that is passed to it when it is called for
   // later use by the headerReCopyToFrom. The original buffer position points
   // to where the header should be copied. This call then forward advances
   // the buffer to point past the header. Forward advancing the buffer
   // position to point just after where the header should be is the same as
   // doing a pretend copy of the header. After this pretend copy of the
   // header, the buffer position points to where the data should be put into
   // the buffer.
   //
   // Store the original buffer position for later use by the
   // headerReCopyToFrom and advance the buffer position forward
   // to point past the header.

   if (aBuffer->isCopyTo())
   {
      // Store the buffer object for later use.
      mOriginalBuffer = *aBuffer;
      // Advance the buffer position to point past the header.
      aBuffer->forward(Header::Length);
   }

   //---------------------------------------------------------------------
   // for a "copy from" get
   //
   // If this is a "copy from" get operation then copy the header from the
   // buffer into the header member. Also set the message content type from
   // the variable datum id

   else
   {
      // Copy the buffer content into the header object.
      copyToFrom(aBuffer);
      // Set the message content type.
      parent->mMessageType = mMessageType;
      parent->mFamily      = mFamily;
   }
}

//------------------------------------------------------------------------------
// These are called explicitly by inheriting messages at the
// beginning and end of their copyToFrom's to manage the headers.
// For "get" operations, headerCopyToFrom "gets" the header and
// headerReCopyToFrom does nothing. For "put" operations,
// headerCopyToFrom does nothing except store the buffer pointer and
// headerReCopyToFrom "puts" the header at the stored position. Both
// functions are passed a byte buffer pointer to where the copy is
// to take place. Both are also passed a MessageContent pointer to
// where they can get MessageContent::mFamily and mMessageType which
// they transfer into and out of the headers.
//------------------------------------------------------------------------------

void Header::headerReCopyToFrom (Ris::ByteBuffer* aBuffer,Ris::MessageContent* parent)
{
   // If this is a put operation then this actually copies the header into
   // the buffer.
   // This sets some header length parameters and copies the header into the
   // buffer position that was stored when headerCopyToFrom was called.

   if (aBuffer->isCopyTo())
   {
      mMessageType   = parent->mMessageType;
      mFamily        = parent->mFamily;
      mMessageLength = aBuffer->getLength();

      copyToFrom(&mOriginalBuffer);
   }
}

//******************************************************************************
//******************************************************************************
//******************************************************************************

void  MessageParser::configure(int aSourceId)
{
   mSourceId=aSourceId;
}

//******************************************************************************

int  MessageParser::getHeaderLength()
{
   return Header::Length;
}

//******************************************************************************

void MessageParser::getMessageHeaderParms(Ris::ByteBuffer* aBuffer,Ris::MessageHeaderParms* aParms)
{
   Header tHeader;   
   aBuffer->get(&tHeader);

   aParms->mHeaderLength   = Header::Length;;
   aParms->mMessageLength  = tHeader.mMessageLength;
   aParms->mMessageType    = tHeader.mMessageType;
   aParms->mPayloadLength  = tHeader.mMessageLength - Header::Length;
   aParms->mValidFlag      = tHeader.validateContent();
}

//******************************************************************************

Ris::ByteContent* MessageParser::createMessage(int aMessageType)
{
   return BaseMsg::createMessage(aMessageType);
}

//******************************************************************************

void  MessageParser::processBeforeSend(Ris::ByteContent* aMsg)
{
   BaseMsg* tx = (BaseMsg*)aMsg;

   if (tx->mHeader.mSourceId==0)
   {
      tx->mHeader.mSourceId=mSourceId;
   }
}

//******************************************************************************
//******************************************************************************
//******************************************************************************

BaseMsg::BaseMsg ()
{
   mFamily=MsgIdT::Family;
}

//******************************************************************************

BaseMsg* BaseMsg::cloneMessage()
{
   // Create a new message based on message type
   BaseMsg* msg = createMessage(mMessageType);

   // Byte buffer
   Ris::ByteBuffer buffer(MsgBufferSize);  

   // Copy this message to buffer
   buffer.putToBuffer(this);

   // Copy buffer to new message
   buffer.rewind();
   buffer.getFromBuffer(msg);

   return msg;
}

//******************************************************************************
//******************************************************************************
//******************************************************************************

const char* BaseMsg::getNameOf ()
{
   return MsgIdT::asString(mMessageType);
}

//******************************************************************************
//******************************************************************************
//******************************************************************************
// This creates a new message, based on a message type

BaseMsg* BaseMsg::createMessage(int aMessageType)
{
   BaseMsg* tMsg = 0;

   switch (aMessageType)
   {
      case MsgIdT::RunTest :
         tMsg = new RunTestMsg;
         break;
      case MsgIdT::RunTestAck :
         tMsg = new RunTestAckMsg;
         break;
      case MsgIdT::TestCompletion :
         tMsg = new TestCompletionMsg;
         break;
      case MsgIdT::PrintStr :
         tMsg = new PrintStrMsg;
         break;
      case MsgIdT::CmdLineStr :
         tMsg = new CmdLineStrMsg;
         break;
      default :
         return 0;
         break;
   }
   return tMsg;
}

//******************************************************************************
//******************************************************************************
//******************************************************************************

RunTestMsg::RunTestMsg()
{
   mMessageType = MsgIdT::RunTest;
   mTestName[0]=0;
} 

//-------------------------------------------------------

void RunTestMsg::copyToFrom (Ris::ByteBuffer* aBuffer)
{
   mHeader.headerCopyToFrom(aBuffer,this);
  
   aBuffer->copyZString (   mTestName,StringSize );

   mHeader.headerReCopyToFrom(aBuffer,this);
}

//******************************************************************************
//******************************************************************************
//******************************************************************************

RunTestAckMsg::RunTestAckMsg()
{
   mMessageType = MsgIdT::RunTestAck;
} 

//-------------------------------------------------------

void RunTestAckMsg::copyToFrom (Ris::ByteBuffer* aBuffer)
{
   mHeader.headerCopyToFrom(aBuffer,this);
  
   mHeader.headerReCopyToFrom(aBuffer,this);
}

//******************************************************************************
//******************************************************************************
//******************************************************************************

TestCompletionMsg::TestCompletionMsg()
{
   mMessageType = MsgIdT::TestCompletion;
   mTestName[0]=0;
} 

//-------------------------------------------------------

void TestCompletionMsg::copyToFrom (Ris::ByteBuffer* aBuffer)
{
   mHeader.headerCopyToFrom(aBuffer,this);
  
   aBuffer->copyZString (   mTestName,StringSize );

   mHeader.headerReCopyToFrom(aBuffer,this);
}

//******************************************************************************
//******************************************************************************
//******************************************************************************

PrintStrMsg::PrintStrMsg()
{
   mMessageType = MsgIdT::PrintStr;
   mPrintStr[0]=0;
} 

PrintStrMsg::PrintStrMsg(char* aPrintStr)
{
   mMessageType = MsgIdT::PrintStr;
   strcpy(mPrintStr,aPrintStr);
} 

//-------------------------------------------------------

void PrintStrMsg::copyToFrom (Ris::ByteBuffer* aBuffer)
{
   mHeader.headerCopyToFrom(aBuffer,this);
  
   aBuffer->copyZString (   mPrintStr,StringSize );

   mHeader.headerReCopyToFrom(aBuffer,this);
}

//******************************************************************************
//******************************************************************************
//******************************************************************************

CmdLineStrMsg::CmdLineStrMsg()
{
   mMessageType = MsgIdT::CmdLineStr;
   mCmdLineStr[0]=0;
} 

CmdLineStrMsg::CmdLineStrMsg(char* aCmdLineStr)
{
   mMessageType = MsgIdT::CmdLineStr;
   strcpy(mCmdLineStr,aCmdLineStr);
} 

//-------------------------------------------------------

void CmdLineStrMsg::copyToFrom (Ris::ByteBuffer* aBuffer)
{
   mHeader.headerCopyToFrom(aBuffer,this);
  
   aBuffer->copyZString (   mCmdLineStr,StringSize );

   mHeader.headerReCopyToFrom(aBuffer,this);
}

}//namespace
}//namespace


